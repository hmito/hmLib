#ifndef HMLIB_TYPEMANAGE_STRINGBUILD_INC
#define HMLIB_TYPEMANAGE_STRINGBUILD_INC 100
#
#include<type_traits>>
namespace hmLib{
	namespace typemanage{
		template<typename my_type>
		struct default_string_build:public my_type::string_build{};
		template<typename my_type,typename string_build_=default_string_build<my_type>>
		struct string_build{
		private:
			string_build_  Type;
		public:
			template<typename input_iterator>
			my_type operator()(input_iterator begin,input_iterator end){
				return Type(begin,end);
			}
			template<typename output_iterator>
			void label(output_iterator itr,const std::string& pre)const{
				Type.label(itr,pre);
			}
			unsigned int size()const{
				return Type.size();
			}
		};
	}
}
#
#endif

