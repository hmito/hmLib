#ifndef HMLIB_TYPEMANAGE_PARAMETER_INC
#define HMLIB_TYPEMANAGE_PARAMETER_INC 100
#
#include<type_traits>
namespace hmLib{
	namespace typemanage{
		template<typename my_type>
		struct default_parameter:public my_type::parameter{};
		template<typename my_type,typename parameter_=default_parameter<my_type>>
		struct parameter{
		private:
			parameter_ Type;
		public:
			template<typename output_iterator>
			void operator()(output_iterator itr,const my_type& my)const{
				Type(itr,my);
			}
			template<typename output_iterator>
			void label(output_iterator itr,const std::string& pre)const{
				Type.label(itr,pre);
			}
			unsigned int size()const{
				return Type.size();
			}
		};
	}
}
#
#endif
